export default class Aula {
  id: number;
  nome: string;
  duracao: number;
  idCurso: number;
  topicos: string[];

  constructor() {}
}
