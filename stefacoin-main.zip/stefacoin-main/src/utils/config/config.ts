export default {
  port: 3000,
  name: 'stefacoin-backend',
  auth: {
    expiresIn: '1d',
    secret: 'K9xfPv773dZR22TVUB80xouzdF7qCg5cWjPjkHyv7Ws',
  },
};
