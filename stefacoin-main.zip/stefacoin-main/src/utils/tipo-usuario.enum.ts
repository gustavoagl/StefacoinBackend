export enum TipoUsuario {
  PROFESSOR = 1,
  ALUNO = 2,
}
