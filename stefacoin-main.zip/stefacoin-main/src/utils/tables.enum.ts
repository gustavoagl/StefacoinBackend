export enum Tables {
  ALUNO = 'ALUNO',
  PROFESSOR = 'PROFESSOR',
  CURSO = 'CURSO',
  USUARIO = 'USUARIO',
}
