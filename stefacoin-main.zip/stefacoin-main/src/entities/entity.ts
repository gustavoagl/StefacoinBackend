export default class Entity {
  constructor() {}

  get id(): number {
    return this.id;
  }

  set id(id: number) {
    this.id = id;
  }
}
